﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CustomAttribute;
using System.Reflection;

namespace AttributeConsole
{
    [CustomAttribute.AnimalAttribute("TestScience")]
    class Program
    {
        static void Main(string[] args)
        {
            Assembly asmInfo;
            asmInfo = Assembly.Load("AttributeConsole");

            MemberInfo info = typeof(Giraffe);
            object[] attrs = info.GetCustomAttributes(false);            

            CustomAttribute.AnimalAttribute animTest;

            animTest = (CustomAttribute.AnimalAttribute)attrs[0];

            Console.WriteLine("Scientific Name for Giraffes: " + animTest.scientificName + "\nAnimal Weight: " + animTest.animalWeight);

            CustomAttribute.AnimalAttribute animTest2;

            MemberInfo info2 = typeof(Lion);
            object[] attrs2 = info2.GetCustomAttributes(false);

            animTest2 = (CustomAttribute.AnimalAttribute)attrs2[0];

            Console.WriteLine("\nScientific Name for Lion: " + animTest2.scientificName + "\nAnimal Weight: " + animTest2.animalWeight);


            Console.WriteLine("\nPress Enter to continue");
            Console.ReadLine();

            
        }
    }
}
