﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomAttribute
{
    [AttributeUsage(AttributeTargets.All)]
    public class AnimalAttribute : System.Attribute
    {
        public string scientificName;
        public int animalWeight;

        public AnimalAttribute(string Name)
        {
            this.scientificName = Name;
        }

        public string ScientificName
        {
            get
            {
                return scientificName;
            }

            set
            {
                scientificName = value;
            }
        }

        public int AnimalWeight
        {
            get
            {
                return animalWeight;
            }

            set
            {
                animalWeight = value;
            }
        }

        public string returnTest (string test) { return "test"; }
    }
}
