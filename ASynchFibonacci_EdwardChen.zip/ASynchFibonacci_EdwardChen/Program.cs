﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ASynchFibonacci_EdwardChen
{
    class Program
    {
        static void Main(string[] args)
        {
            int userInput;
            bool loop = true;                        

            while (loop)
            {
                Console.WriteLine("Please input a number of the Fibonacci sequence: ");
                if (int.TryParse(Console.ReadLine(), out userInput))
                {
                    var fib = Fibonacci(userInput);                    
                    while (fib.IsCompleted == false) { Console.WriteLine("continuing to work on Thread" + fib.Id); fib.Wait(1000); }
                    Console.WriteLine("The number is " + fib.Result);

                    loop = false;
                }
                else
                {
                    Console.WriteLine("That's not a number!\n");
                }
            }


            Console.WriteLine("That's the end of this program!\n");
            Console.WriteLine("Press any key to continue..");
            Console.ReadLine();
        }                

        async static Task<int> Fibonacci(int n)
        {
            if (n == 0) { return 0; }
            else if (n == 1) { return 1; }
            else
            {
                // run one of the recursions concurrently
                var t1 = Task.Factory.StartNew(() => Fibonacci(n - 1));
                var t2 = Fibonacci(n - 2);                
                return (await (await t1)) + (await t2);
            }
        }

    }

}
