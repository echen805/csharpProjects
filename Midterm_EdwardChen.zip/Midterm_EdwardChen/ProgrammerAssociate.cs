﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Midterm_EdwardChen
{
    class ProgrammerAssociate : Employee, ICompany
    {
        #region Fields
        private int programlanguages = 4;
        private decimal bonusAmount = 0;


        #endregion

        #region Constructors
        public ProgrammerAssociate()
        {
            ID = 999;
            JobTitle = "New Programmer Associate";
            firstName = "Unknown";
            lastName = "Unknown";
            Birthdate = DateTime.MinValue;
            Hiredate = DateTime.MinValue;
            Salary = 500;
            programlanguages = 4;
        }

        public ProgrammerAssociate(int empId, string title, string firstnameInput, string lastNameInput, DateTime birthdateInput, DateTime hiredateInput, decimal currentSalary,
            int programmingExperience)
        {
            ID = empId;
            JobTitle = title;
            firstName = firstnameInput;
            lastName = lastNameInput;
            Birthdate = birthdateInput;
            Hiredate = hiredateInput;
            Salary = currentSalary;
            programlanguages = programmingExperience;
        }
        #endregion

        #region Properties
        public int programExperience
        {
            get
            {
                return programlanguages;
            }

            set
            {
                programlanguages = value;
            }
        }

        public decimal BonusAmount
        {
            get
            {
                return bonusAmount;
            }

            set
            {
                bonusAmount = value;
            }
        }

        public string JobPosition
        {
            get
            {
                return JobTitle;
            }

            set
            {
                JobTitle = value; 
            }
        }

        public decimal currentSalary
        {
            get
            {
                throw new NotImplementedException();
            }

            set
            {
                throw new NotImplementedException();
            }
        }

        public string Name
        {
            get
            {
                throw new NotImplementedException();
            }

            set
            {
                throw new NotImplementedException();
            }
        }

        public Decimal calculateBonus()
        {
            if (programlanguages > 6)
            {
                bonusAmount = Salary * 0.05M;
                return bonusAmount;
            }
            else
                if (programlanguages > 8)
            {
                bonusAmount = Salary * 0.10M;
                return bonusAmount;
            }

            else
            {
                if (programlanguages > 10)
                {
                    bonusAmount = Salary * 0.20M;
                    return bonusAmount;
                }

                else
                    return bonusAmount;
            }
        }

        public override string ToString()
        {
            return $"{ID,5} {JobTitle,10} {lastName,8} {firstName,10}" +
                $"{Hiredate,23:MM/dd/yyyy} {Birthdate,15:MM/dd/yyyy}" +
                $"{ Salary,18:C} {YearsEmployed(),8} { BonusAmount,15 } { programlanguages,15}";
        }

        public int CompareTo(ICompany other)
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}
