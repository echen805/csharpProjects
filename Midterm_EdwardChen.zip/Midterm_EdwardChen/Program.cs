﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Midterm_EdwardChen
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Employee.ReportHeader());

            SalesManager Manager1 = new SalesManager(101, "Sales Manager", "Jim","Halpert",DateTime.Parse("1/23/1955"),DateTime.Parse("5/14/2000"),100000,7000,900);            
            SalesManager Manager2 = new SalesManager(102, "Sales Manager", "Carol", "Smith", DateTime.Parse("2/23/1993"), DateTime.Parse("9/5/2011"), 7580, 500, 600);            
            SalesManager Manager3 = new SalesManager(103, "Sales Manager", "Bill", "Goode", DateTime.Parse("1/11/2004"), DateTime.Parse("3/12/2012"), 5600, 0, 800);
            SalesAssociate SalesAssc1 = new SalesAssociate(201, "Sales Associate", "Dwight", "Howard", DateTime.Parse("3/24/1984"), DateTime.Parse("6/12/2010"), 2400, 30);            
            SalesAssociate SalesAssc2 = new SalesAssociate(202, "Sales Associate", "Homer", "Grant", DateTime.Parse("5/1/1987"), DateTime.Parse("2/2/2011"), 4300, 15);            
            SalesAssociate SalesAssc3 = new SalesAssociate(203, "Sales Associate", "Elena", "Garcia", DateTime.Parse("4/4/1995"), DateTime.Parse("3/24/2007"), 3400, 5);
            Programmer Pr1 = new Programmer(301, "Programmer", "Dwayne", "Johnson", DateTime.Parse("6/21/1988"), DateTime.Parse("8/14/2002"), 70000, 300, 3);
            Programmer Pr2 = new Programmer(302, "Programmer", "Jim", "Dean", DateTime.Parse("9/21/1988"), DateTime.Parse("10/14/2002"), 70000, 300, 3);
            Programmer Pr3 = new Programmer(303, "Programmer", "Michael", "Jordon", DateTime.Parse("11/21/1988"), DateTime.Parse("3/14/2002"), 70000, 300, 3);
            ProgrammerAssociate PrAsc1 = new ProgrammerAssociate(501, "Programmer Associate", "Paula", "Dean",DateTime.Parse("5/23/1977"),DateTime.Parse("3/13/1990"),90000,7);
            ProgrammerAssociate PrAsc2 = new ProgrammerAssociate(502, "Programmer Associate", "Guy", "Fieri", DateTime.Parse("5/23/1982"), DateTime.Parse("3/13/1993"), 85000, 5);
            ProgrammerAssociate PrAsc3 = new ProgrammerAssociate(503, "Programmer Associate", "Ina", "Garten", DateTime.Parse("5/23/1985"), DateTime.Parse("3/13/1998"), 93000, 97);


            System.Collections.Generic.List<Employee> company = new System.Collections.Generic.List<Employee>();            
            company.Add(Manager1);
            company.Add(Manager2);
            company.Add(Manager3);
            company.Add(SalesAssc1);
            company.Add(SalesAssc2);
            company.Add(SalesAssc3);
            company.Add(Pr1);
            company.Add(Pr2);
            company.Add(Pr3);
            company.Add(PrAsc1);
            company.Add(PrAsc2);
            company.Add(PrAsc3);

            foreach (Employee s in company)
            {
                Console.WriteLine(s); ;
            }

            Console.WriteLine("\nPress any key to continue");
            Console.ReadKey();
        }
    }
}
