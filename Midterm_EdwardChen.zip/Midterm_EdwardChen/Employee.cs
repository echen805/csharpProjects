﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Midterm_EdwardChen
{
    
    class Employee
    {
        #region Fields
        private int _ID = 0;
        private DateTime birthdate = DateTime.MinValue;
        private DateTime hiredate = DateTime.MinValue;
        private decimal salary = 0;
        private string jobTitle ="";

        private static int empCount = 0;
        #endregion

        #region Constructors
        public Employee() : this(0, "New Hire", "Unknown", "Unknown", DateTime.MinValue, DateTime.MinValue, 0) { }
        public Employee(int empId, string title, string firstnameInput, string lastNameInput, DateTime birthdateInput, DateTime hiredateInput, decimal currentSalary)
        {
            this._ID = empId;
            this.jobTitle = title;
            this.firstName = firstnameInput;
            this.lastName = lastNameInput;
            this.birthdate = birthdateInput;
            this.hiredate = hiredateInput;
            salary = currentSalary;


            empCount++;
        }
        #endregion

        #region Properties
        public int ID
        {
            get
            {
                return _ID;
            }

            set
            {
                this._ID = value;
            }
        }

        public DateTime Birthdate
        {
            get
            {
                return birthdate;
            }

            set
            {
                if (value <= DateTime.Now)
                    birthdate = value;
                else
                    throw new ArgumentOutOfRangeException("DOB", "The date of birth must be less than the current date. ");
            }
        }

        public DateTime Hiredate
        {
            get
            {
                return hiredate;
            }

            set
            {
                if (value <= DateTime.Now)
                    hiredate = value;
                else
                    throw new ArgumentOutOfRangeException("Hire Date", "The hire date must be less than the current date. ");

            }
        }

        public decimal Salary
        {
            get
            {
                return salary;
            }

            set
            {
                if (value >= 0)
                    salary = value;
                else
                    throw new ArgumentOutOfRangeException("Salary", "The salary must be greater than 0. ");


            }
        }


        public string firstName { get; set; } = String.Empty;
        public string lastName { get; set; } = String.Empty;

        public string JobTitle
        {
            get
            {
                return jobTitle;
            }

            set
            {
                jobTitle = value;
            }
        }


        #endregion

        #region Methods

        public int DaysEmployed()
        {
            DateTime oldDate = Hiredate;
            DateTime currentDate = DateTime.Now;

            //Difference in days, hours and minutes 
            TimeSpan ts = currentDate - oldDate;

            int differenceDays = ts.Days;

            return differenceDays;
        }

        public int YearsEmployed()
        {
            DateTime currentDate = DateTime.Now;
            int years = currentDate.Year - Hiredate.Year;

            if ((currentDate.Month == Hiredate.Month) ||
                (currentDate.Month == Hiredate.Month) && (currentDate.Day < Hiredate.Day))
            {
                --years;
            }
            return years;
        }

        public static string ReportHeader()
        {
            Console.SetWindowSize(150, 20);
            //return $"Employee EIS\n" +
            //    $"{"ID",5} {"Job Title",10} {"Last Name",-5} { "First Name",-25} {"DOB",-13}" +
            //    $"{ "Hire Date",-11} {"Salary",8} {"Bonus",15} {"Special Skills",15}";

            return $"Employee EIS\n \n" + $"Depending on the job, there are special skills. These are the special skills per job:\n" +
                $"Programmer and Programmer Associate means the number of languages they know. \n" +
                $"Sales Associate has the number of sales while Sales Manager is the total sales of the division. \n" +
                $"President has the number of years worked in a upper management position. \n \n" +
                $"{"ID",5} {"Job Title",10} {"Last Name",13} { "First Name",13} {"Hire Date",15}" +
                $"{ "DOB",12} {"Salary",20} {"Years Employed", 18} {"Bonus",9} {"Special Skills",20}";
        }



        //public override string ToString()
        //{
        //    return $"{ID,5} {JobTitle,5} {lastName,-20} {firstName,-15}" +
        //        $"{this.YearsEmployed()} " +
        //        $"{ Salary,10:C} { empCount,15}";
        //}

        #endregion


    }
}
