﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Midterm_EdwardChen
{
    class Programmer : Employee
    {
        #region Fields
        private int programLanguages = 1;
        private int bonusAmount = 0;        


        #endregion

        #region Constructors
        public Programmer()
        {
            ID = 999;
            JobTitle = "New Programmer";
            firstName = "Unknown";
            lastName = "Unknown";
            Birthdate = DateTime.MinValue;
            Hiredate = DateTime.MinValue;
            Salary = 50000;
            bonusAmount = 300;
            programLanguages = 2;
        }

        public Programmer(int empId, string title, string firstnameInput, string lastNameInput, DateTime birthdateInput, DateTime hiredateInput, decimal currentSalary, 
            int bonusInput, int programmingLanguages)
        {
            ID = empId;
            JobTitle = title;
            firstName = firstnameInput;
            lastName = lastNameInput;
            Birthdate = birthdateInput;
            Hiredate = hiredateInput;
            Salary = currentSalary;
            bonusAmount = bonusInput;
            programLanguages = programmingLanguages;
        }
        #endregion

        #region Properties
        public int Experience
        {
            get
            {
                return programLanguages;
            }

            set
            {
                programLanguages = value;
            }
        }

        
        

        public override string ToString()
        {
            return $"{ID,5} {JobTitle,10} {lastName,8} {firstName,10}" +
                $"{Hiredate,23:MM/dd/yyyy} {Birthdate,15:MM/dd/yyyy}" +
                $"{ Salary,18:C} {YearsEmployed(),8} { bonusAmount,15} { programLanguages,15}";
        }

        #endregion
    }
}
