﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Midterm_EdwardChen
{
    class President : Employee
    {
        #region Fields
        private int carAllowance = 0;
        private decimal bonusAmount = 0;


        #endregion

        #region Constructors
        public President()
        {
            ID = 999;
            JobTitle = "New President";
            firstName = "Unknown";
            lastName = "Unknown";
            Birthdate = DateTime.MinValue;
            Hiredate = DateTime.MinValue;
            Salary = 500;
            carAllowance = 3000;
        }

        public President(int empId, string title, string firstnameInput, string lastNameInput, DateTime birthdateInput, DateTime hiredateInput, decimal currentSalary, int allowancePerDay)
        {
            ID = empId;
            JobTitle = title;
            firstName = firstnameInput;
            lastName = lastNameInput;
            Birthdate = birthdateInput;
            Hiredate = hiredateInput;
            Salary = currentSalary;
            carAllowance = allowancePerDay;
        }
        #endregion

        #region Properties
        public int CarPerDiem
        {
            get
            {
                return carAllowance;
            }

            set
            {
                carAllowance = value;
            }
        }

        public decimal BonusAmount
        {
            get
            {
                return bonusAmount;
            }

            set
            {
                bonusAmount = value;
            }
        }

        public override string ToString()
        {
            return $"{ID,5} {JobTitle, 10} {lastName,-25} {firstName,-25}" +
                $"{Hiredate,-11:MM/dd/yyyy} {Birthdate,-11:MM/dd/yyyy}" +
                $"{ Salary,10:C} { BonusAmount,15 } { carAllowance,15}";
        }

        #endregion
    }
}
