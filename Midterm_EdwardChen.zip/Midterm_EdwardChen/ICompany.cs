﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Midterm_EdwardChen
{
    public interface ICompany:IComparable<ICompany>
    {
        string JobPosition { get; set; }
        decimal currentSalary { get; set; }
        string Name { get; set; }
    }
}
