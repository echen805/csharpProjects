﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Midterm_EdwardChen
{
    class SalesManager : Employee
    {
        #region Fields
        //private int stock = 0;
        private decimal bonusAmount = 0;
        private int carAllowwance = 0;
        private int yearsWorked = 0;

        #endregion

        #region Constructors
        public SalesManager()
        {
            ID = 000;
            JobTitle = "New Manager"; 
            firstName = "Unknown";
            lastName = "Unknown";
            Birthdate = DateTime.MinValue;
            Hiredate = DateTime.MinValue;
            Salary = 1000;
            yearsWorked = 0;
            bonusAmount = 0;
            carAllowwance = 1000;
        }

        public SalesManager(int empId, string title, string firstnameInput, string lastNameInput, DateTime birthdateInput, DateTime hiredateInput, decimal currentSalary,
            decimal bonusAmt, int carPerDiem)
        {
            ID = empId;
            JobTitle = title;
            firstName = firstnameInput;
            lastName = lastNameInput;
            Birthdate = birthdateInput;
            Hiredate = hiredateInput;
            Salary = currentSalary;
            yearsWorked = this.YearsEmployed();
            bonusAmount = bonusAmt;
            carAllowwance = carPerDiem;
        }
        #endregion

        #region Properties
        //public int Stock
        //{
        //    get
        //    {
        //        return stock;
        //    }

        //    set
        //    {
        //        stock = value;
        //    }
        //}

        public decimal BonusAmount
        {
            get
            {
                return bonusAmount;
            }

            set
            {
                bonusAmount = value;
            }
        }


        //Under the assumption we are supposed to ask for user input
        //public Decimal calculateBonus ()
        //{
        //    int number=0;

        //    Console.WriteLine("What percentage of the salary should the manager receive?");
        //    string input = Console.ReadLine();
        //    bool result = Int32.TryParse(input, out number);
        //    if (result)
        //        bonusAmount = Salary * number;
        //    else
        //    {
        //        Console.WriteLine("Please input a number");
        //        calculateBonus();
        //    }
        //    return bonusAmount;
        //}

        public int getTotalSales()
        {
            int tempSalesCount = 0;

            SalesAssociate temp = new SalesAssociate();
            tempSalesCount = temp.getSalesCount() - 1;

            return tempSalesCount;
        }

        public Decimal calculateBonus()
        {
            
            bonusAmount = Salary * this.getTotalSales();
            return bonusAmount;
        }

        public override string ToString()
        {
            //return $"{ID,5} {JobTitle} {lastName,-25} {firstName,-25}" +
            //    $"{Hiredate,-11:MM/dd/yyyy} {Birthdate,-11:MM/dd/yyyy}" +
            //    $"{ Salary,10:C} { Stock,15} { bonusAmount,15 } {carAllowwance, 15}";

            return $"{ID,5} {JobTitle,10} {lastName,8} {firstName,10}" +
                $"{Hiredate,23:MM/dd/yyyy} {Birthdate,15:MM/dd/yyyy}" +
                $"{ Salary,18:C} { yearsWorked, 8} { bonusAmount, 15} {carAllowwance, 15}";

        }

        #endregion
    }
}
