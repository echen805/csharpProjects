﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Midterm_EdwardChen
{
    class SalesAssociate : Employee
    {
        #region Fields
        private int sales = 0;
        private decimal bonusAmount = 0;
        private int salesCount = 0;


        #endregion

        #region Constructors
        public SalesAssociate()
        {
            ID = 999;
            JobTitle = "New Sales Associate";
            firstName = "Unknown";
            lastName = "Unknown";
            Birthdate = DateTime.MinValue;
            Hiredate = DateTime.MinValue;
            Salary = 500;
            sales = 1;

            salesCount += sales;
        }

        public SalesAssociate(int empId, string title, string firstnameInput, string lastNameInput, DateTime birthdateInput, DateTime hiredateInput, decimal currentSalary, int salesOptions)
        {
            ID = empId;
            JobTitle = title;
            firstName = firstnameInput;
            lastName = lastNameInput;
            Birthdate = birthdateInput;
            Hiredate = hiredateInput;
            Salary = currentSalary;
            sales = salesOptions;

            salesCount += sales;
        }
        #endregion

        #region Properties
        public int Sales
        {
            get
            {
                return sales;
            }

            set
            {
                sales = value;
            }
        }

        public decimal BonusAmount
        {
            get
            {
                return bonusAmount;
            }

            set
            {
                bonusAmount = value;
            }
        }

        public Decimal calculateBonus()
        {
            if (sales > 10)
            {
                bonusAmount = Salary * 0.05M;
                return bonusAmount;
            }
            else
                if (sales > 20)
            {
                bonusAmount = Salary * 0.10M;
                return bonusAmount;
            }

            else
            {
                if (sales > 30)
                {
                    bonusAmount = Salary * 0.20M;
                    return bonusAmount;
                }

                else
                    return bonusAmount;
            }
        }

        public int getSalesCount()
        {
            return salesCount;
        }

        public override string ToString()
        {
            return $"{ID,5} {JobTitle,10} {lastName,8} {firstName,10}" +
                $"{Hiredate,23:MM/dd/yyyy} {Birthdate,15:MM/dd/yyyy}" +
                $"{ Salary,18:C} {YearsEmployed(),8} { BonusAmount,15 } { Sales,15}";
        }

        #endregion
    }
}
